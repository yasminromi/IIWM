% Example to test min function getCoordinates on the line

A = [1,1,1];
B = [11,31,51];

all = getCoordinatesOnTheLine(A,B,10)