% MiniTest to function findClosestPoint

a = [1;2;2]';

b = [[1,2,4];[1,2,3];[2,2,2];[3,2,1];];

bClosest = findClosestPoint(a,b)
coordinates = getCoordinatesOnTheLine()